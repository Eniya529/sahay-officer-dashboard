import type { ReactNode } from 'react';
import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { AppRoute } from '../../types';
import { NotificationDrawer } from './NotificationDrawer';
import { 
  Shield, 
  LayoutDashboard, 
  FileText, 
  UserCheck, 
  Calendar, 
  BarChart3, 
  Bell, 
  User, 
  LogOut, 
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

export const OfficerSidebar: React.FC = () => {
  const { currentRoute, setCurrentRoute, setUserRole } = useApp();
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const navItems: { route: AppRoute; label: string; icon: ReactNode }[] = [
    { route: 'officer-dash', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { route: 'officer-cases', label: 'Cases', icon: <FileText className="w-4 h-4" /> },
    { route: 'officer-allocation', label: 'Officer Allocation', icon: <UserCheck className="w-4 h-4" /> },
    { route: 'officer-followups', label: 'Follow-ups', icon: <Calendar className="w-4 h-4" /> },
    { route: 'officer-analytics', label: 'Analytics', icon: <BarChart3 className="w-4 h-4" /> }
  ];

  const isNavActive = (r: AppRoute) => {
    if (r === 'officer-cases' && currentRoute === 'officer-case-detail') return true;
    return currentRoute === r;
  };

  const handleNavClick = (route: AppRoute) => {
    setCurrentRoute(route);
    setIsMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Top Header Toggle */}
      <div className="lg:hidden bg-white border-b border-line px-4 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center space-x-2">
          <Shield className="w-5 h-5 text-teal-600" />
          <span className="font-black text-slate-900 text-base">SAHAY PORTAL</span>
        </div>

        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="p-2 rounded-lg bg-teal-50 text-muted hover:text-slate-900 border border-line"
        >
          {isMobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar Desktop Rail & Mobile Drawer */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-white border-r border-line flex flex-col justify-between transition-transform duration-300 shadow-sm ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* TOP BRAND AREA */}
        <div className="p-5 border-b border-line space-y-3">
          <div 
            onClick={() => handleNavClick('officer-dash')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-300 p-2 flex items-center justify-center shadow-sm group-hover:border-teal-500 transition">
              <Shield className="w-6 h-6 text-teal-600" />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-slate-900 flex items-center gap-1.5">
                SAHAY
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-teal-100 text-teal-700 border border-teal-300">
                  OFFICER
                </span>
              </h1>
              <p className="text-[10px] text-muted font-medium">Response Intelligence & Workspace</p>
            </div>
          </div>
        </div>

        {/* MAIN NAVIGATION LIST */}
        <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <span className="px-3 text-[10px] uppercase font-bold text-muted tracking-wider">
            Response Workspace
          </span>

          <nav className="space-y-1 pt-1">
            {navItems.map((item) => {
              const active = isNavActive(item.route);
              return (
                <button
                  key={item.route}
                  onClick={() => handleNavClick(item.route)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition ${
                    active
                      ? 'bg-gradient-to-r from-teal-500 to-teal-600 text-white shadow-md shadow-teal-500/30 border border-teal-300'
                      : 'text-muted hover:text-slate-900 hover:bg-teal-50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className={active ? 'text-white' : 'text-muted'}>{item.icon}</span>
                    <span>{item.label}</span>
                  </div>
                  {active && <ChevronRight className="w-3.5 h-3.5 text-white/80" />}
                </button>
              );
            })}
          </nav>
        </div>

        {/* BOTTOM UTILITY & PROFILE SECTION */}
        <div className="p-3 border-t border-line space-y-2">
          {/* Notifications Button */}
          <button
            onClick={() => setIsNotificationOpen(true)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-white hover:bg-teal-50 border border-line text-xs font-semibold text-muted hover:text-slate-900 transition"
          >
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-amber-500" />
              <span>Notifications</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-bold">
              3
            </span>
          </button>

          {/* Officer Profile Card */}
          <div className="p-3 rounded-xl bg-teal-50/60 border border-line space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-teal-100 border border-teal-300 flex items-center justify-center text-teal-600">
                <User className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <h4 className="text-xs font-bold text-slate-900 truncate">Officer Rajesh Kumar</h4>
                <p className="text-[10px] text-muted truncate">NHAA-884 · Senior Officer</p>
              </div>
            </div>
          </div>

          {/* Logout / Switch Role */}
          <button
            onClick={() => {
              setUserRole('victim');
              setCurrentRoute('home');
            }}
            className="w-full flex items-center justify-center space-x-2 px-3 py-2 rounded-xl bg-white hover:bg-emergency-50 border border-line hover:border-emergency-300 text-muted hover:text-emergency-600 text-xs font-semibold transition"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Switch / Logout</span>
          </button>
        </div>
      </aside>

      {/* Notification Drawer */}
      <NotificationDrawer isOpen={isNotificationOpen} onClose={() => setIsNotificationOpen(false)} />
    </>
  );
};