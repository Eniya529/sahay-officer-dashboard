import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Shield,
  AlertOctagon,
  AlertTriangle,
  Clock,
  ChevronRight,
  Radio,
  MapPin,
  ArrowUpRight,
  CheckCircle2,
} from 'lucide-react';

export const OfficerDashboard: React.FC<{
  onSelectCase?: (caseId: string) => void;
}> = ({ onSelectCase }) => {
  const {
    cases,
    setSelectedCaseId,
    setCurrentRoute,
  } = useApp();

  const [filterPriority, setFilterPriority] =
    useState<string>('ALL');

  // ============================================================
  // REAL FIREBASE / APP DATA
  // ============================================================

  const activeCount = cases.length;

  const criticalCount = cases.filter(
    (c) => c.sviLevel === 'CRITICAL'
  ).length;

  const highCount = cases.filter(
    (c) => c.sviLevel === 'HIGH'
  ).length;

  const awaitingReviewCount = cases.filter(
    (c) =>
      c.status === 'AWAITING_REVIEW' ||
      c.status === 'Pending' ||
      c.status === 'Requires Human Review'
  ).length;

  const followupsCount = cases.reduce(
    (total, c) =>
      total +
      (Array.isArray(c.followUpHistory)
        ? c.followUpHistory.filter(
            (followUp) =>
              followUp.status === 'Pending'
          ).length
        : 0),
    0
  );

  // ============================================================
// ALL FIREBASE CASES
// ============================================================

const filteredAttentionCases =
  cases.filter((c) => {
    if (filterPriority === 'ALL') {
      return true;
    }

    return c.sviLevel === filterPriority;
  });

  // ============================================================
  // OPEN CASE DETAIL
  // ============================================================

  const handleReviewCaseClick = (
    caseId: string
  ) => {
    setSelectedCaseId(caseId);

    if (onSelectCase) {
      onSelectCase(caseId);
    }

    setCurrentRoute(
      'officer-case-detail'
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 animate-fadeIn">

      {/* ======================================================
          HEADER
      ====================================================== */}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-line pb-4">

        <div>

          <div className="flex items-center space-x-2">

            <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Shield className="w-6 h-6 text-teal-600" />

              Response Pulse & Action Dashboard
            </h2>

            <span className="px-2.5 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-300 text-[10px] font-bold">
              LIVE PULSE
            </span>

          </div>

          <p className="text-xs text-muted">
            Real-time public response intelligence,
            priority intake queue, and human decision
            support workspace.
          </p>

        </div>


        <div className="flex items-center space-x-3">

          <span className="px-3 py-1.5 rounded-xl bg-white border border-line text-xs font-semibold text-slate-900/80 flex items-center space-x-2 shadow-sm">

            <Radio className="w-3.5 h-3.5 text-teal-600 animate-pulse" />

            <span>
              Active Desk Officer:{' '}
              <strong className="text-teal-700 font-mono">
                Officer Rajesh Kumar (NHAA-884)
              </strong>
            </span>

          </span>

        </div>

      </div>


      {/* ======================================================
          RESPONSE PULSE
      ====================================================== */}

      <section className="space-y-3">

        <div className="flex items-center justify-between">

          <h3 className="text-xs font-bold text-muted uppercase tracking-wider flex items-center gap-2 font-mono">

            <Radio className="w-4 h-4 text-teal-600 animate-pulse" />

            RESPONSE PULSE

          </h3>

          <span className="text-[11px] text-muted">
            Live Telemetry & Queue Telemetry
          </span>

        </div>


        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">

          {/* ==================================================
              ACTIVE CASES
          ================================================== */}

          <div className="soft-card p-4 rounded-2xl space-y-1">

            <span className="text-[10px] font-bold uppercase text-muted">
              Active Cases
            </span>

            <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
              {activeCount}
            </div>

            <span className="text-[10px] text-muted block">
              Total cases logged
            </span>

          </div>


          {/* ==================================================
              CRITICAL
          ================================================== */}

          <div className="p-4 rounded-2xl border border-emergency-300 bg-emergency-50 space-y-1">

            <div className="flex items-center justify-between">

              <span className="text-[10px] font-bold uppercase text-emergency-600">
                Critical
              </span>

              {criticalCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-emergency-500 animate-ping" />
              )}

            </div>

            <div className="text-2xl sm:text-3xl font-black text-emergency-700 font-mono">
              {criticalCount}
            </div>

            <span className="text-[10px] text-emergency-600/80 block">
              Immediate attention
            </span>

          </div>


          {/* ==================================================
              HIGH PRIORITY
          ================================================== */}

          <div className="p-4 rounded-2xl border border-amber-300 bg-amber-50 space-y-1">

            <div className="flex items-center justify-between">

              <span className="text-[10px] font-bold uppercase text-amber-600">
                High Priority
              </span>

              <AlertTriangle className="w-4 h-4 text-amber-500" />

            </div>

            <div className="text-2xl sm:text-3xl font-black text-amber-700 font-mono">
              {highCount}
            </div>

            <span className="text-[10px] text-amber-600/80 block">
              Priority review
            </span>

          </div>


          {/* ==================================================
              AWAITING REVIEW
          ================================================== */}

          <div className="p-4 rounded-2xl border border-lavender-300 bg-lavender-50 space-y-1">

            <div className="flex items-center justify-between">

              <span className="text-[10px] font-bold uppercase text-lavender-600">
                Awaiting Review
              </span>

              <Clock className="w-4 h-4 text-lavender-600" />

            </div>

            <div className="text-2xl sm:text-3xl font-black text-lavender-700 font-mono">
              {awaitingReviewCount}
            </div>

            <span className="text-[10px] text-lavender-600/80 block">
              Pending decision
            </span>

          </div>


          {/* ==================================================
              FOLLOW-UPS
          ================================================== */}

          <div className="p-4 rounded-2xl border border-sage-300 bg-sage-50 space-y-1 col-span-2 sm:col-span-1">

            <div className="flex items-center justify-between">

              <span className="text-[10px] font-bold uppercase text-sage-700">
                Follow-ups Due
              </span>

              <CheckCircle2 className="w-4 h-4 text-sage-600" />

            </div>

            <div className="text-2xl sm:text-3xl font-black text-sage-700 font-mono">
              {followupsCount}
            </div>

            <span className="text-[10px] text-sage-600/80 block">
              Due today
            </span>

          </div>

        </div>


        {/* ====================================================
            PRIORITY ACTIVITY
        ==================================================== */}

        <div className="p-3 rounded-xl bg-white border border-line text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-sm">

          <div className="flex items-center space-x-2 text-slate-900/80">

            <ArrowUpRight className="w-4 h-4 text-amber-500 shrink-0" />

            <span className="font-bold text-amber-700">
              Priority Activity:
            </span>

            <span>
              {criticalCount > 0 || highCount > 0
                ? `${criticalCount + highCount} high-priority case${
                    criticalCount + highCount !== 1
                      ? 's'
                      : ''
                  } currently require officer attention.`
                : 'No high-priority cases currently require immediate attention.'}
            </span>

          </div>


          <button
            onClick={() =>
              setCurrentRoute(
                'officer-cases'
              )
            }
            className="text-[11px] text-teal-600 hover:text-teal-700 font-bold whitespace-nowrap self-end sm:self-auto"
          >
            View All Cases →
          </button>

        </div>

      </section>


      {/* ======================================================
          NEEDS YOUR ATTENTION
      ====================================================== */}

      <section className="space-y-4 pt-2">

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-line pb-3">

          <div>

            <h3 className="text-base font-black text-slate-900 tracking-wide uppercase flex items-center gap-2">

              <AlertOctagon className="w-5 h-5 text-emergency-600" />

              NEEDS YOUR ATTENTION

            </h3>

            <p className="text-xs text-muted">
              High vulnerability cases requiring human
              officer review and decision dispatch.
            </p>

          </div>


          <div className="flex items-center space-x-2">

            <div className="flex items-center p-1 rounded-xl bg-white border border-line text-xs shadow-sm">

              {['ALL', 'CRITICAL', 'HIGH'].map(
                (lvl) => (

                  <button
                    key={lvl}
                    onClick={() =>
                      setFilterPriority(lvl)
                    }
                    className={`px-3 py-1 rounded-lg font-semibold transition ${
                      filterPriority === lvl
                        ? 'bg-teal-500 text-white'
                        : 'text-muted hover:text-slate-900'
                    }`}
                  >
                    {lvl}
                  </button>

                )
              )}

            </div>

          </div>

        </div>


        {/* ====================================================
            PRIORITY CASE CARDS
        ==================================================== */}

        {filteredAttentionCases.length === 0 ? (

          <div className="rounded-2xl border border-line bg-white p-8 text-center shadow-sm">

            <CheckCircle2 className="w-8 h-8 text-sage-600 mx-auto mb-3" />

            <h4 className="text-sm font-bold text-slate-900">
              No priority cases
            </h4>

            <p className="text-xs text-muted mt-1">
              There are currently no Critical or High
              vulnerability cases requiring immediate
              attention.
            </p>

          </div>

        ) : (

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

            {filteredAttentionCases.map(
              (c) => {

                const isCritical =
                  c.sviLevel === 'CRITICAL';

                return (

                  <div
                    key={c.id}
                    onClick={() =>
                      handleReviewCaseClick(
                        c.id
                      )
                    }
                    className="soft-card p-5 rounded-2xl hover:border-teal-300 transition cursor-pointer space-y-4 group relative overflow-hidden"
                  >

                    {/* TOP ROW */}

                    <div className="flex items-center justify-between">

                      <div className="flex items-center space-x-2.5">

                        <span
                          className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                            isCritical
                              ? 'bg-emergency-500 animate-ping'
                              : 'bg-amber-400'
                          }`}
                        />

                        <span className="font-mono font-bold text-teal-700 text-sm tracking-wider">
                          {c.id}
                        </span>

                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-black border uppercase tracking-wider ${
                            isCritical
                              ? 'bg-emergency-100 text-emergency-700 border-emergency-300'
                              : 'bg-amber-100 text-amber-700 border-amber-300'
                          }`}
                        >
                          {c.sviLevel}
                        </span>

                      </div>


                      <div className="text-right">

                        <span className="text-[10px] text-muted font-mono block uppercase">
                          SVI SCORE
                        </span>

                        <span className="text-lg font-black text-slate-900 font-mono">
                          {c.sviScore}
                        </span>

                      </div>

                    </div>


                    {/* CASE BRIEF */}

                    <div className="space-y-1.5">

                      <h4 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition">

                        {c.summary ||
                          'Case requires officer review.'}

                      </h4>


                      {c.keyEvidence &&
                        c.keyEvidence.length >
                          0 && (

                          <p className="text-xs text-amber-700 italic p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                            "{c.keyEvidence[0]}"
                          </p>

                        )}

                    </div>


                    {/* METADATA */}

                    <div className="grid grid-cols-2 gap-2 text-xs text-muted pt-2 border-t border-line">

                      <div className="flex items-center space-x-1.5 truncate">

                        <MapPin className="w-3.5 h-3.5 text-muted shrink-0" />

                        <span className="truncate">

                          {c.location ||
                            c.district ||
                            c.state ||
                            'Location unavailable'}

                        </span>

                      </div>


                      <div className="flex items-center space-x-1.5 justify-end text-muted">

                        <Clock className="w-3.5 h-3.5 text-muted shrink-0" />

                        <span>
                          Updated {c.lastUpdate}
                        </span>

                      </div>

                    </div>


                    {/* ACTION */}

                    <div className="pt-1 flex items-center justify-between">

                      <span className="text-[11px] text-muted font-medium">

                        Status:{' '}

                        <strong className="text-slate-900/80">
                          {c.status}
                        </strong>

                      </span>


                      <button
                        onClick={(e) => {
                          e.stopPropagation();

                          handleReviewCaseClick(
                            c.id
                          );
                        }}
                        className={`px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center space-x-1.5 shadow-md ${
                          isCritical
                            ? 'bg-emergency-500 hover:bg-emergency-600 text-white'
                            : 'bg-teal-500 hover:bg-teal-600 text-white'
                        }`}
                      >

                        <span>
                          Review Case
                        </span>

                        <ChevronRight className="w-4 h-4" />

                      </button>

                    </div>

                  </div>

                );
              }
            )}

          </div>

        )}

      </section>

    </div>
  );
};